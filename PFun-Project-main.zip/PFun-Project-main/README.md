# depresso shooter scooter  
- PFun Final Project made using Python and PyGame

# Main Game Files  
- depresso shooter scooter.py  
- images and sounds folder  

# Requirements:
- python  
- pygame -pip install pygame  
